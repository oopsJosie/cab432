## CAB432 REST API Project (Node.js + Express + Docker + SQLite + JWT)

# Introduction

This project is implemented according to the requirements of QUT CAB432 Assessment 1:

# CPU-intensive task: 
Uses worker_threads to render Mandelbrot fractal images in parallel (PNG output).

# Load testing script: 
scripts/loadtest.js can drive CPU usage above 80% for several minutes.

# Data types (at least two, excluding user authentication data):

Unstructured data: Rendered PNG images stored in data/images/.

Structured (ACID) data: SQLite database records image metadata (owner, size, parameters, timestamp, etc.).

Additional data type (for bonus credit: Additional types of data): 
User preference configurations stored as JSON in data/settings/ (sample endpoint provided).

# Containerisation: 
Includes a Dockerfile, can be pushed to AWS ECR and deployed on EC2.

# Deployment: 
Provides scripts/deploy-ecr.sh to demonstrate pulling and running the container from ECR.

# REST API: 
Versioned under /api/v1/, includes authentication, image listing/download, and CPU-intensive task endpoints. Supports pagination, sorting, and filtering.

# User authentication JWT: 
JWT-based login with two hard-coded demo users (alice: admin, bob: user) to showcase role-based logic.

## Additional criteria 

🌸 Extended API features: Pagination, sorting, filtering, versioned routes.

🌸 External APIs: /api/v1/palettes/random integrates with The Color API to fetch random palettes for fractal coloring.

🌸 Custom processing: Custom fractal rendering algorithm with multi-threaded concurrency control.

🌸 Infrastructure as code: Includes docker-compose.yml (for local/demo usage) and ECR deployment script.

🌸 Web client: Simple web interface under public/ to interact with all API endpoints.


## Quick Start (Local)
1) Install dependencies (Node.js 18/20 recommended)
```bash
npm install
```

2) Start the server
```bash
npm start
```
Visit http://localhost:3000

# Or use Docker:
```bash
docker compose up --build
```
Visit http://localhost:3000

## Accounts (Demo)

- Tom / 123456 (admin)
- Ben / 123456 (user)

After logging in, obtain the JWT to access protected endpoints.

## API Overview

- POST /api/v1/auth/login -> Login, returns a JWT.
- POST /api/v1/images/generate (auth) -> Trigger CPU-intensive fractal rendering. Optional parameters: width, height, maxIterations, palette (hex array).
- GET /api/v1/images (auth) -> List images, supports page, pageSize, sort, order, owner.
- GET /api/v1/images/:id (auth) -> Retrieve metadata.
- GET /api/v1/images/:id/file -> Download PNG file.
- GET /api/v1/palettes/random -> Fetch a random monochromatic palette from The Color API.

## Load Testing (>80% CPU sustained for ~5 minutes)

1) Log in to obtain TOKEN (first retrieve it via /auth/login)
export TOKEN=eyJ...

2) R un load test (8 concurrent, 1800 iterations, lasting 5 minutes)
node scripts/loadtest.js http://localhost:80 8 1800 5

```bash
export TOKEN=...
node scripts/loadtest.js http://localhost:80 8 1800 5

```

Monitor CPU usage on the server with top/htop

## Deployment Workflow

1. **Build with Docker**  
   Package the application into a container image using Docker.  

2. **Push to ECR**  
   Tag and push the Docker image to Amazon Elastic Container Registry.  

3. **Deploy on EC2**  
   On the EC2 instance, pull the image from ECR and run the container.  

## Docker Deployment

```bash

# Authenticate with ECR (Login Succeeded expected)
aws ecr get-login-password --region ap-southeast-2 \
| docker login --username AWS --password-stdin 901444280953.dkr.ecr.ap-southeast-2.amazonaws.com

# Build multi-arch (amd64 + arm64) and push as v2
docker buildx build \
  --platform linux/amd64,linux/arm64 \
  -t 901444280953.dkr.ecr.ap-southeast-2.amazonaws.com/n11501910-assessment1:v2 \
  --push .

```

## Deployment to AWS (ECR and EC2)

```bash

# On EC2: authenticate to ECR (add sudo if needed)
aws ecr get-login-password --region ap-southeast-2 \
| sudo docker login --username AWS --password-stdin 901444280953.dkr.ecr.ap-southeast-2.amazonaws.com

# Pull v2 image
sudo docker pull 901444280953.dkr.ecr.ap-southeast-2.amazonaws.com/n11501910-assessment1:v2

# Ensure writable data directory for DB/images
sudo mkdir -p /home/ssm-user/cab432/data
sudo chown -R ssm-user:ssm-user /home/ssm-user/cab432

# Replace existing container (ignore errors if it doesn't exist)
sudo docker stop n11501910-assessment1 2>/dev/null || true
sudo docker rm   n11501910-assessment1 2>/dev/null || true

# Run container on port 80
sudo docker run -d \
  --name n11501910-assessment1 \
  --restart unless-stopped \
  -p 80:3000 \
  -e JWT_SECRET='ABCEFG123456789!@#$%' \
  -e IMAGE_DIR=/app/data/images \
  -e DB_PATH=/app/data/app.sqlite \
  -v /home/ssm-user/cab432/data:/app/data \
  901444280953.dkr.ecr.ap-southeast-2.amazonaws.com/n11501910-assessment1:v2

# (Optional) Run load test inside the container (use port 3000 inside container)
sudo docker exec -it n11501910-assessment1 /bin/bash -lc '
  export TOKEN=eyJ...;
  for i in {1..4}; do
    node scripts/loadtest.js http://localhost:3000 8 1800 10 &
  done
'
```
