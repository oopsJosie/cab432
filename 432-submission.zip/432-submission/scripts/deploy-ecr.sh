
#!/usr/bin/env bash
set -euo pipefail

# Required env vars (provided by CAB432 AWS account / your IAM role):
#   AWS_ACCOUNT_ID, AWS_REGION, ECR_REPO (repository name), IMAGE_TAG
# Example:
#   export AWS_ACCOUNT_ID=123456789012
#   export AWS_REGION=ap-southeast-2
#   export ECR_REPO=cab432-rest-api
#   export IMAGE_TAG=v2
#
# Build, tag, push image to ECR, then show docker command for EC2.
[ -z "${AWS_ACCOUNT_ID:-}" ] && { echo "AWS_ACCOUNT_ID env missing"; exit 1; }
[ -z "${AWS_REGION:-}" ] && { echo "AWS_REGION env missing"; exit 1; }
[ -z "${ECR_REPO:-}" ] && { echo "ECR_REPO env missing"; exit 1; }
IMAGE_TAG="${IMAGE_TAG:-latest}"

FULL_URI="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${ECR_REPO}:${IMAGE_TAG}"

aws ecr get-login-password --region "$AWS_REGION" | docker login --username AWS --password-stdin "${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"

docker build -t "${ECR_REPO}:${IMAGE_TAG}" .
docker tag "${ECR_REPO}:${IMAGE_TAG}" "${FULL_URI}"
docker push "${FULL_URI}"

echo "Pushed: ${FULL_URI}"
echo "On EC2:"
cat <<EC2CMD
docker pull ${FULL_URI}
docker run -d --name cab432 -p 80:3000 -e JWT_SECRET=\"change-me\" ${FULL_URI}
EC2CMD
