
/**
 * Simple load generator to push CPU >80% for several minutes.
 * Usage:
 *   export TOKEN=...
 *   node scripts/loadtest.js http://localhost:3000 8 1800 10
 *     baseUrl concurrents maxIterations minutes
 */
import axios from 'axios';

const baseUrl = process.argv[2] || 'http://localhost:3000';
const concurrents = parseInt(process.argv[3] || '4');
const maxIterations = parseInt(process.argv[4] || '1800');
const minutes = parseInt(process.argv[5] || '5');

const TOKEN = process.env.TOKEN;
if (!TOKEN) {
  console.error('Please export TOKEN from /api/v1/auth/login');
  process.exit(1);
}

const endTime = Date.now() + minutes * 60 * 1000;

async function worker(id) {
  while (Date.now() < endTime) {
    try {
      await axios.post(baseUrl + '/api/v1/images/generate', {
        width: 960, height: 540, maxIterations
      },{ headers:{ Authorization: 'Bearer ' + TOKEN }});
      // Immediately fire next without delay to keep CPU busy
    } catch (e) {
      // ignore; keep hammering
    }
  }
  console.log('worker', id, 'done');
}

(async () => {
  await Promise.all(Array.from({length: concurrents}, (_,i) => worker(i+1)));
  console.log('Load test finished.');
})();
