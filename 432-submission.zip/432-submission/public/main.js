let TOKEN = '';
let currentPage = 1;

async function loadHistory() {
  if (!TOKEN) {
    alert('Please login first!');
    return;
  }
  const owner = document.getElementById('filterOwner').value.trim();
  const sort = document.getElementById('sortField').value;
  const order = document.getElementById('sortOrder').value;
  const pageSize = parseInt(document.getElementById('pageSize').value) || 6;

  const params = new URLSearchParams({
    page: currentPage,
    pageSize,
    sort,
    order
  });
  if (owner) params.append('owner', owner);

  const resp = await fetch('/api/v1/images?' + params.toString(), {
    headers: { 'Authorization': 'Bearer ' + TOKEN }
  });
  const data = await resp.json();

  const container = document.getElementById('history');
  container.innerHTML = '';
  if (data.items && data.items.length) {
    data.items.forEach(item => {
      const div = document.createElement('div');
      div.className = 'history-item';
      const img = document.createElement('img');
      img.src = `/api/v1/images/${item.id}/file`;
      const meta = document.createElement('div');
      meta.className = 'meta';
      meta.textContent = `${item.width}x${item.height}, it=${item.maxIterations}, owner=${item.owner}, ${item.createdAt}`;
      div.appendChild(img);
      div.appendChild(meta);
      container.appendChild(div);
    });
  } else {
    container.innerHTML = '<p>No history records</p>';
  }

  document.getElementById('pageInfo').textContent = `Page ${currentPage}`;
}

document.getElementById('login').onclick = async () => {
  const username = document.getElementById('u').value;
  const password = document.getElementById('p').value;
  const resp = await fetch('/api/v1/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  const data = await resp.json();
  if (data.token) {
    TOKEN = data.token;
    document.getElementById('jwt').textContent = data.token.slice(0, 40) + '...';
    currentPage = 1;
    loadHistory();
  } else {
    alert('Login failed');
  }
};

document.getElementById('palette').onclick = async () => {
  const resp = await fetch('/api/v1/palettes/random');
  const data = await resp.json();
  const el = document.getElementById('paletteView');
  el.innerHTML = '';
  if (data.palette && data.palette.length) {
    data.palette.forEach(hex => {
      const box = document.createElement('div');
      box.className = 'color-box';
      box.style.backgroundColor = `#${hex}`;
      el.appendChild(box);
    });
    el.dataset.palette = JSON.stringify(data.palette);
  }
};

document.getElementById('render').onclick = async () => {
  if (!TOKEN) {
    alert('Please login first!');
    return;
  }
  const width = parseInt(document.getElementById('w').value);
  const height = parseInt(document.getElementById('h').value);
  const maxIterations = parseInt(document.getElementById('it').value);
  const palEl = document.getElementById('paletteView');
  const palette = palEl.dataset.palette ? JSON.parse(palEl.dataset.palette) : undefined;

  const resp = await fetch('/api/v1/images/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + TOKEN },
    body: JSON.stringify({ width, height, maxIterations, palette })
  });
  const data = await resp.json();
  if (data.id) {
    const img = document.createElement('img');
    img.src = `/api/v1/images/${data.id}/file`;
    document.getElementById('output').prepend(img);
    currentPage = 1;
    loadHistory();
  } else {
    alert(JSON.stringify(data));
  }
};

document.getElementById('applyFilters').onclick = () => {
  currentPage = 1;
  loadHistory();
};

document.getElementById('prevPage').onclick = () => {
  if (currentPage > 1) {
    currentPage--;
    loadHistory();
  }
};

document.getElementById('nextPage').onclick = () => {
  currentPage++;
  loadHistory();
};
