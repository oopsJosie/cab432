import { parentPort, workerData } from 'worker_threads';

function computeJuliaTile({ x0, y0, x1, y1, width, height, maxIterations, cRe, cIm }) {
    const data = new Uint32Array(width * height);

    for (let j = 0; j < height; j++) {
        const y = y0 + (j / height) * (y1 - y0);
        for (let i = 0; i < width; i++) {
            const x = x0 + (i / width) * (x1 - x0);

            // 
            let zx = x;
            let zy = y;
            let iter = 0;

            while (zx*zx + zy*zy < 4 && iter < maxIterations) {
                const xt = zx*zx - zy*zy + cRe;
                zy = 2*zx*zy + cIm;
                zx = xt;
                iter++;
            }

            data[j * width + i] = iter;
        }
    }

    return data;
}

const result = computeJuliaTile(workerData);
parentPort.postMessage({ data: result }, [result.buffer]);
