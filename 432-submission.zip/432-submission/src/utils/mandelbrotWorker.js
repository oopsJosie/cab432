
import { parentPort, workerData } from 'worker_threads';

function computeTile({ x0, y0, x1, y1, width, height, maxIterations }) {
  const data = new Uint32Array(width * height);
  for (let j = 0; j < height; j++) {
    const y = y0 + (j / height) * (y1 - y0);
    for (let i = 0; i < width; i++) {
      const x = x0 + (i / width) * (x1 - x0);
      let zx = 0, zy = 0, iter = 0;
      while (zx*zx + zy*zy <= 4 && iter < maxIterations) {
        const xt = zx*zx - zy*zy + x;
        zy = 2*zx*zy + y;
        zx = xt;
        iter++;
      }
      data[j * width + i] = iter;
    }
  }
  return data;
}

const result = computeTile(workerData);
parentPort.postMessage({ data: result }, [result.buffer]);
