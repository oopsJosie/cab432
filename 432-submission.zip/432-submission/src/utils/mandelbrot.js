
import { Worker } from 'worker_threads';
import os from 'os';
import path from 'path';
import fs from 'fs';
import { createCanvas } from 'canvas';
import { v4 as uuidv4 } from 'uuid';

// Generate a palette array from hex strings
function buildPalette(hexes) {
  const pal = [];
  for (const h of hexes) {
    const hex = h.replace('#','');
    const r = parseInt(hex.slice(0,2),16);
    const g = parseInt(hex.slice(2,4),16);
    const b = parseInt(hex.slice(4,6),16);
    pal.push([r,g,b]);
  }
  return pal;
}

export async function generateMandelbrot({ width=1920, height=1080, maxIterations=1000, palette=['000000','003049','d62828','f77f00','fcbf49','eae2b7'], outDir }) {
  const cpu = Math.max(1, os.cpus().length);
  const tileHeight = Math.ceil(height / cpu);
  const x0 = -2.5, x1 = 1;
  const y0 = -1, y1 = 1;

  const promises = [];
  for (let t = 0; t < cpu; t++) {
    const startRow = t * tileHeight;
    const th = Math.min(tileHeight, height - startRow);
    if (th <= 0) break;
    const worker = new Worker(new URL('./mandelbrotWorker.js', import.meta.url), {
      workerData: {
        x0, x1,
        y0: y0 + (startRow/height)*(y1 - y0),
        y1: y0 + ((startRow + th)/height)*(y1 - y0),
        width,
        height: th,
        maxIterations
      }
    });
    promises.push(new Promise((resolve, reject) => {
      worker.on('message', (msg) => resolve({ idx: t, data: msg.data }));
      worker.on('error', reject);
    }));
  }

  const results = await Promise.all(promises);
  results.sort((a,b) => a.idx - b.idx);

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const imgData = ctx.createImageData(width, height);
  const paletteArr = buildPalette(palette);

  let rowOffset = 0;
  for (const r of results) {
    const data = new Uint32Array(r.data);
    for (let j = 0; j < data.length; j++) {
      const iter = data[j];
      let color = [0,0,0];
      if (iter < maxIterations) {
        const c = paletteArr[iter % paletteArr.length];
        color = c;
      }
      const k = (rowOffset + j) * 4;
      imgData.data[k] = color[0];
      imgData.data[k+1] = color[1];
      imgData.data[k+2] = color[2];
      imgData.data[k+3] = 255;
    }
    rowOffset += data.length;
  }
  ctx.putImageData(imgData, 0, 0);

  // save
  const id = uuidv4();
  const filename = `${id}.png`;
  await fs.promises.mkdir(outDir, { recursive: true });
  const full = path.join(outDir, filename);
  await fs.promises.writeFile(full, canvas.toBuffer('image/png'));
  return { id, filename };
}
